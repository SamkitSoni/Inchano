import {EIP712TypedData} from '@1inch/fusion-sdk'
import {isCardanoTestnet} from './cardano-chain.config'
import {
    CardanoWalletApi,
    CardanoSignedData,
    CardanoUtxo,
    CardanoBridgeOrder
} from './types'
import WebSocket from 'ws'
import {EventEmitter} from 'events'

export interface RelayerWebSocketMessage {
    type:
        | 'subscribe'
        | 'unsubscribe'
        | 'ping'
        | 'pong'
        | 'order_update'
        | 'order_created'
        | 'order_filled'
        | 'order_cancelled'
        | 'profitable_opportunity'
    data?: any
    timestamp: number
    clientId?: string
}

export interface CardanoProviderConfig {
    relayerWsUrl?: string
    enableWebSocket?: boolean
    reconnectInterval?: number
    maxReconnectAttempts?: number
}

/**
 * Cardano blockchain provider connector for cross-chain operations
 * Handles Cardano-specific wallet interactions, transaction signing, and WebSocket communication with relayer
 */
export class CardanoProviderConnector extends EventEmitter {
    private ws?: WebSocket
    private reconnectAttempts = 0
    private reconnectTimer?: NodeJS.Timeout
    private isConnecting = false
    private subscriptions = new Set<string>()
    private config: CardanoProviderConfig

    constructor(
        private readonly cardanoWallet: CardanoWalletApi,
        config: CardanoProviderConfig = {}
    ) {
        super()
        this.config = {
            enableWebSocket: true,
            reconnectInterval: 5000,
            maxReconnectAttempts: 10,
            ...config
        }

        if (this.config.enableWebSocket && this.config.relayerWsUrl) {
            this.initWebSocket()
        }
    }

    /**
     * Sign transaction data using Cardano wallet
     * Note: Cardano uses different signing mechanisms than EVM chains
     */
    async signTransactionData(
        walletAddress: string,
        transactionData: any
    ): Promise<CardanoSignedData> {
        if (!this.cardanoWallet) {
            throw new Error('Cardano wallet not connected')
        }

        try {
            const signature = await this.cardanoWallet.signTx(
                transactionData.cbor,
                true // partialSign for multi-sig scenarios
            )

            return {
                signature,
                publicKey: await this.getPublicKey(walletAddress)
            }
        } catch (error) {
            throw new Error(`Failed to sign Cardano transaction: ${error}`)
        }
    }

    /**
     * Get wallet's public key for verification
     */
    async getPublicKey(address: string): Promise<string> {
        const changeAddress = await this.cardanoWallet.getChangeAddress()
        return changeAddress
    }

    /**
     * Get UTXOs for transaction building
     */
    async getUtxos(amount?: string): Promise<CardanoUtxo[]> {
        const utxos = await this.cardanoWallet.getUtxos(amount)
        return utxos || []
    }

    /**
     * Get wallet's balance
     */
    async getBalance(): Promise<string> {
        const balance = await this.cardanoWallet.getBalance()
        return balance
    }

    /**
     * Submit signed transaction to Cardano network
     */
    async submitTransaction(signedTx: string): Promise<string> {
        const txHash = await this.cardanoWallet.submitTx(signedTx)
        return txHash
    }

    /**
     * Check if wallet is connected and available
     */
    async isConnected(): Promise<boolean> {
        try {
            await this.cardanoWallet.getNetworkId()
            return true
        } catch {
            return false
        }
    }

    /**
     * Get current network ID (mainnet = 1, testnet = 0)
     */
    async getNetworkId(): Promise<number> {
        return await this.cardanoWallet.getNetworkId()
    }

    private initWebSocket(): void {
        if (!this.config.relayerWsUrl || this.isConnecting) return

        this.isConnecting = true
        this.ws = new WebSocket(this.config.relayerWsUrl)

        this.ws.on('open', () => {
            console.log('Cardano WS connected')
            this.reconnectAttempts = 0
            this.isConnecting = false
            this.resubscribe()
            this.emit('connect')
        })

        this.ws.on('message', (data: WebSocket.Data) => {
            try {
                const message: RelayerWebSocketMessage = JSON.parse(
                    data.toString()
                )
                this.handleWebSocketMessage(message)
            } catch (error) {
                console.error('Error parsing WS message:', error)
            }
        })

        this.ws.on('close', () => {
            console.log('Cardano WS disconnected')
            this.emit('disconnect')
            this.handleReconnect()
        })

        this.ws.on('error', (error: Error) => {
            console.error('Cardano WS error:', error)
            this.emit('error', error)
            // The 'close' event will be called next, which handles reconnection.
        })
    }

    private handleWebSocketMessage(message: RelayerWebSocketMessage): void {
        this.emit('message', message)

        switch (message.type) {
            case 'order_created':
            case 'order_update':
            case 'order_filled':
            case 'order_cancelled':
                this.emit(message.type, message.data)
                break
            case 'pong':
                this.emit('pong', message.data)
                break
            default:
                console.log(`Received unhandled message type: ${message.type}`)
        }
    }

    private handleReconnect(): void {
        if (
            this.reconnectAttempts < (this.config.maxReconnectAttempts || 10) &&
            !this.reconnectTimer
        ) {
            this.reconnectAttempts++
            console.log(
                `Attempting to reconnect... (${this.reconnectAttempts}/${this.config.maxReconnectAttempts})`
            )
            this.reconnectTimer = setTimeout(() => {
                this.reconnectTimer = undefined
                this.initWebSocket()
            }, this.config.reconnectInterval || 5000)
        } else if (!this.reconnectTimer) {
            console.error('Max reconnect attempts reached.')
        }
    }

    private sendMessage(message: Partial<RelayerWebSocketMessage>): void {
        if (this.ws?.readyState !== WebSocket.OPEN) {
            console.error('WebSocket is not open.')
            return
        }
        this.ws.send(JSON.stringify({...message, timestamp: Date.now()}))
    }

    private resubscribe(): void {
        const currentSubscriptions = new Set(this.subscriptions)
        this.subscriptions.clear()

        currentSubscriptions.forEach((sub) => {
            const [type, filters] = sub.split(':')
            this.subscribe(type, filters ? JSON.parse(atob(filters)) : {})
        })
    }

    /**
     * Subscribes to real-time updates for orders or other events.
     */
    subscribe(type: string, filters: object = {}): void {
        const subscriptionKey = `${type}:${btoa(JSON.stringify(filters))}`
        this.subscriptions.add(subscriptionKey)

        this.sendMessage({
            type: 'subscribe',
            data: {subscription: type, filters}
        })
    }

    /**
     * Unsubscribes from real-time updates.
     */
    unsubscribe(type: string, filters: object = {}): void {
        const subscriptionKey = `${type}:${btoa(JSON.stringify(filters))}`
        this.subscriptions.delete(subscriptionKey)

        this.sendMessage({
            type: 'unsubscribe',
            data: {subscription: type, filters}
        })
    }

    /**
     * Gracefully closes the WebSocket connection.
     */
    close(): void {
        if (this.reconnectTimer) {
            clearTimeout(this.reconnectTimer)
            this.reconnectTimer = undefined
        }
        this.ws?.close()
    }

    /**
     * Submit a new cross-chain order to the relayer
     */
    async submitCrossChainOrder(order: CardanoBridgeOrder): Promise<any> {
        // The relayer will handle the creation of the order
        // and broadcast it via WebSocket. The client will be
        // notified through its subscription.
        this.sendMessage({
            type: 'order_created',
            data: {order}
        })

        // Optionally, you can return a promise that resolves when the order_created event is received.
        return new Promise((resolve, reject) => {
            this.once('order_created', (data) => {
                if (data.order.id === order.id) {
                    resolve(data)
                }
            })

            // Timeout to prevent indefinite waiting
            setTimeout(() => {
                reject(new Error('Timeout waiting for order creation confirmation'))
            }, 10000) // 10 seconds timeout
        })
    }

    /**
     * Get WebSocket connection status
     */
    getWebSocketStatus(): {
        connected: boolean
        readyState: number | null
        subscriptions: string[]
        reconnectAttempts: number
    } {
        return {
            connected: this.ws?.readyState === WebSocket.OPEN,
            readyState: this.ws?.readyState || null,
            subscriptions: Array.from(this.subscriptions),
            reconnectAttempts: this.reconnectAttempts
        }
    }

    /**
     * Manually trigger WebSocket reconnection
     */
    reconnect(): void {
        if (this.ws) {
            this.ws.close()
        }
        this.reconnectAttempts = 0
        this.initWebSocket()
    }

    /**
     * Send ping to keep connection alive
     */
    ping(): void {
        this.sendMessage({
            type: 'ping',
            data: {timestamp: Date.now()}
        })
    }

    /**
     * Check if the Cardano network supports testnet operations
     * Uses Sepolia equivalent settings for Cardano testnet
     */
    async isTestnetMode(): Promise<boolean> {
        const networkId = await this.getNetworkId()
        return isCardanoTestnet(networkId)
    }

    /**
     * Get comprehensive wallet information
     */
    async getWalletInfo(): Promise<{
        addresses: {
            used: string[]
            unused: string[]
            change: string
            reward: string[]
        }
        balance: string
        networkId: number
        isTestnet: boolean
    }> {
        const [usedAddresses, unusedAddresses, changeAddress, rewardAddresses, balance, networkId] = await Promise.all([
            this.cardanoWallet.getUsedAddresses(),
            this.cardanoWallet.getUnusedAddresses(),
            this.cardanoWallet.getChangeAddress(),
            this.cardanoWallet.getRewardAddresses(),
            this.cardanoWallet.getBalance(),
            this.cardanoWallet.getNetworkId()
        ])

        return {
            addresses: {
                used: usedAddresses,
                unused: unusedAddresses,
                change: changeAddress,
                reward: rewardAddresses
            },
            balance,
            networkId,
            isTestnet: isCardanoTestnet(networkId)
        }
    }
}
