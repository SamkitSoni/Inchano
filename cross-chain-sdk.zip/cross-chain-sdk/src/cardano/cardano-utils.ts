import {CardanoAsset, CardanoValue, CardanoUtxo} from './types'

/**
 * Utility functions for Cardano blockchain operations
 */
export class CardanoUtils {
    /**
     * Convert ADA lovelace to ADA decimal
     */
    static lovelaceToAda(lovelace: string): string {
        return (BigInt(lovelace) / BigInt(1_000_000)).toString()
    }

    /**
     * Convert ADA decimal to lovelace
     */
    static adaToLovelace(ada: string): string {
        return (BigInt(Math.floor(parseFloat(ada) * 1_000_000))).toString()
    }

    /**
     * Check if asset is native ADA
     */
    static isAda(unit: string): boolean {
        return unit === 'lovelace' || unit === ''
    }

    /**
     * Extract policy ID from asset unit
     */
    static getPolicyId(unit: string): string {
        if (this.isAda(unit)) return ''
        return unit.substring(0, 56) // First 56 characters are policy ID
    }

    /**
     * Extract asset name from asset unit
     */
    static getAssetName(unit: string): string {
        if (this.isAda(unit)) return ''
        return unit.substring(56) // Everything after policy ID
    }

    /**
     * Parse asset unit into policy ID and asset name
     */
    static parseAssetUnit(unit: string): {policyId: string; assetName: string} {
        return {
            policyId: this.getPolicyId(unit),
            assetName: this.getAssetName(unit)
        }
    }

    /**
     * Calculate total value of specific asset in UTXOs
     */
    static calculateAssetBalance(utxos: CardanoUtxo[], unit: string): string {
        let total = BigInt(0)

        for (const utxo of utxos) {
            for (const value of utxo.amount) {
                if (value.unit === unit) {
                    total += BigInt(value.quantity)
                }
            }
        }

        return total.toString()
    }

    /**
     * Filter UTXOs that contain specific asset
     */
    static filterUtxosByAsset(utxos: CardanoUtxo[], unit: string): CardanoUtxo[] {
        return utxos.filter(utxo =>
            utxo.amount.some(value => value.unit === unit)
        )
    }

    /**
     * Build Cardano address from bech32 string
     */
    static validateCardanoAddress(address: string): boolean {
        // Basic validation - should be enhanced with proper bech32 validation
        return (
            address.startsWith('addr1') ||
            address.startsWith('addr_test1') ||
            address.startsWith('stake1') ||
            address.startsWith('stake_test1')
        )
    }

    /**
     * Convert hex string to bytes
     */
    static hexToBytes(hex: string): Uint8Array {
        const bytes = new Uint8Array(hex.length / 2)
        for (let i = 0; i < hex.length; i += 2) {
            bytes[i / 2] = parseInt(hex.substr(i, 2), 16)
        }
        return bytes
    }

    /**
     * Convert bytes to hex string
     */
    static bytesToHex(bytes: Uint8Array): string {
        return Array.from(bytes)
            .map(byte => byte.toString(16).padStart(2, '0'))
            .join('')
    }

    /**
     * Create asset fingerprint (CIP-14)
     */
    static createAssetFingerprint(policyId: string, assetName: string): string {
        // This is a simplified version - proper implementation would use CRC8 and bech32
        const combined = policyId + assetName
        return `asset1${combined.substring(0, 38)}`
    }

    /**
     * Calculate minimum ADA required for UTXO
     */
    static calculateMinAda(outputSize: number): string {
        // Simplified calculation - real implementation would use Cardano's minUTXO calculation
        const minAda = BigInt(1_000_000) // 1 ADA as base minimum
        const sizeAdjustment = BigInt(Math.floor(outputSize / 8)) * BigInt(34_482)
        return (minAda + sizeAdjustment).toString()
    }

    /**
     * Build transaction metadata for cross-chain operations
     */
    static buildCrossChainMetadata(params: {
        targetChain: number
        targetAddress: string
        bridgeId?: string
    }): Record<string, any> {
        return {
            674: {
                // Cross-chain metadata label
                target_chain: params.targetChain,
                target_address: params.targetAddress,
                bridge_id: params.bridgeId || 'default',
                timestamp: Date.now()
            }
        }
    }

    /**
     * Estimate transaction fee
     */
    static estimateTransactionFee(params: {
        inputs: number
        outputs: number
        hasMetadata: boolean
        hasScript: boolean
    }): string {
        // Simplified fee calculation - real implementation would use proper fee calculation
        let fee = BigInt(155_381) // Base fee
        fee += BigInt(params.inputs) * BigInt(44_000) // Per input
        fee += BigInt(params.outputs) * BigInt(34_000) // Per output

        if (params.hasMetadata) {
            fee += BigInt(10_000)
        }

        if (params.hasScript) {
            fee += BigInt(50_000)
        }

        return fee.toString()
    }
}

/**
 * Constants for Cardano network
 */
export const CARDANO_CONSTANTS = {
    MIN_ADA: '1000000', // 1 ADA in lovelace
    EPOCH_SECONDS: 432000, // 5 days
    SLOTS_PER_EPOCH: 432000,
    SLOT_LENGTH: 1, // 1 second per slot
    MAX_TX_SIZE: 16384, // 16KB
    MAX_VALUE_SIZE: 5000,
    MAINNET_MAGIC: 764824073,
    TESTNET_MAGIC: 1097911063,
    BECH32_PREFIX: {
        MAINNET_ADDRESS: 'addr1',
        TESTNET_ADDRESS: 'addr_test1',
        MAINNET_STAKE: 'stake1',
        TESTNET_STAKE: 'stake_test1'
    }
} as const
