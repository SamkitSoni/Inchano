/**
 * Cardano-specific types for cross-chain integration
 */

export interface CardanoWalletApi {
    getNetworkId(): Promise<number>
    getUtxos(amount?: string): Promise<CardanoUtxo[]>
    getBalance(): Promise<string>
    getUsedAddresses(): Promise<string[]>
    getUnusedAddresses(): Promise<string[]>
    getChangeAddress(): Promise<string>
    getRewardAddresses(): Promise<string[]>
    signTx(tx: string, partialSign?: boolean): Promise<string>
    signData(addr: string, payload: string): Promise<string>
    submitTx(tx: string): Promise<string>
    getCollateral(): Promise<CardanoUtxo[]>
    enable(): Promise<CardanoWalletApi>
    isEnabled(): Promise<boolean>
}

export interface CardanoUtxo {
    txid: string
    output_index: number
    amount: CardanoValue[]
    address: string
    data_hash?: string
}

export interface CardanoValue {
    unit: string
    quantity: string
}

export interface CardanoSignedData {
    signature: string
    publicKey: string
}

export interface CardanoTransactionData {
    cbor: string
    inputs: CardanoUtxo[]
    outputs: CardanoTxOutput[]
    fee: string
    ttl?: number
}

export interface CardanoTxOutput {
    address: string
    amount: CardanoValue[]
    data_hash?: string
}

export interface CardanoAsset {
    unit: string
    quantity: string
    policyId: string
    assetName: string
}

export interface CardanoOrderParams {
    walletAddress: string
    sourceAsset: CardanoAsset
    targetAsset: CardanoAsset
    amount: string
    receiver?: string
    deadline?: number
    slippageTolerance?: number
}

export interface CardanoQuoteParams {
    srcChainId: number
    dstChainId: number
    srcAssetUnit: string
    dstAssetUnit: string
    amount: string
    walletAddress?: string
    enableEstimate?: boolean
    slippageTolerance?: number
}

export interface CardanoSwapResult {
    transactionId: string
    fee: string
    status: 'pending' | 'confirmed' | 'failed'
    blockHeight?: number
}

export interface CardanoChainConfig {
    id: number
    name: string
    rpcUrl: string
    networkId: number
    magic?: number
    explorerUrl?: string
}

export interface CardanoContractInfo {
    scriptHash: string
    address: string
    parameters?: Record<string, any>
}

/**
 * Cross-chain bridge specific types
 */
export interface CardanoBridgeOrder {
    id: string
    sourceChain: number
    targetChain: number
    sourceAsset: CardanoAsset
    targetAsset: any // Can be EVM token or other chain asset
    amount: string
    recipient: string
    status: 'created' | 'locked' | 'confirmed' | 'executed' | 'cancelled'
    lockTxId?: string
    executeTxId?: string
    created: Date
    expires: Date
}

export interface CardanoLockScript {
    type: 'PlutusV2' | 'PlutusV1' | 'Native'
    script: string
    hash: string
    datumHash?: string
}
