import {NetworkEnum} from '@1inch/fusion-sdk'

export const CardanoChainId = {
    MAINNET: 1815,
    TESTNET: 1816,
    SEPOLIA_TESTNET: 1817  // Sepolia equivalent for Cardano
} as const

export const CARDANO_MAINNET_NETWORK = {
    id: CardanoChainId.MAINNET,
    name: 'Cardano Mainnet',
    rpcUrl: 'https://cardano-mainnet.blockfrost.io/api/v0',
    networkId: 1,
    magic: 764824073,
    explorerUrl: 'https://cardanoscan.io'
}

export const CARDANO_TESTNET_NETWORK = {
    id: CardanoChainId.TESTNET,
    name: 'Cardano Preprod Testnet',
    rpcUrl: 'https://cardano-preprod.blockfrost.io/api/v0',
    networkId: 0,
    magic: 1,
    explorerUrl: 'https://preprod.cardanoscan.io'
}

export const CARDANO_SEPOLIA_TESTNET_NETWORK = {
    id: CardanoChainId.SEPOLIA_TESTNET,
    name: 'Cardano Sepolia Testnet',
    rpcUrl: 'https://cardano-sepolia.blockfrost.io/api/v0',
    networkId: 0,
    magic: 2,  // Different magic number for Sepolia equivalent
    explorerUrl: 'https://sepolia.cardanoscan.io'
}

export const isCardanoChain = (chain: unknown): boolean => {
    return (
        chain === CardanoChainId.MAINNET ||
        chain === CardanoChainId.TESTNET ||
        chain === CardanoChainId.SEPOLIA_TESTNET
    )
}

/**
 * Get network configuration by chain ID
 */
export const getCardanoNetworkConfig = (chainId: number) => {
    switch (chainId) {
        case CardanoChainId.MAINNET:
            return CARDANO_MAINNET_NETWORK
        case CardanoChainId.TESTNET:
            return CARDANO_TESTNET_NETWORK
        case CardanoChainId.SEPOLIA_TESTNET:
            return CARDANO_SEPOLIA_TESTNET_NETWORK
        default:
            throw new Error(`Unsupported Cardano chain ID: ${chainId}`)
    }
}

/**
 * Check if chain ID is Cardano testnet (including Sepolia)
 */
export const isCardanoTestnet = (chainId: number): boolean => {
    return chainId === CardanoChainId.TESTNET || chainId === CardanoChainId.SEPOLIA_TESTNET
}

