import {NetworkEnum} from '@1inch/fusion-sdk'
import {TupleToUnion} from './type-utils'
import {CardanoChainId} from './cardano'

export const SupportedChains = [
    NetworkEnum.ETHEREUM,
    NetworkEnum.POLYGON,
    NetworkEnum.BINANCE,
    NetworkEnum.OPTIMISM,
    NetworkEnum.ARBITRUM,
    NetworkEnum.AVALANCHE,
    NetworkEnum.GNOSIS,
    NetworkEnum.COINBASE,
    NetworkEnum.ZKSYNC,
    NetworkEnum.LINEA,
    NetworkEnum.SONIC,
    NetworkEnum.UNICHAIN,
    CardanoChainId.MAINNET,
    CardanoChainId.TESTNET,
    CardanoChainId.SEPOLIA_TESTNET
] as const

type UnsupportedChain = Exclude<
    NetworkEnum,
    TupleToUnion<typeof SupportedChains>
>

export type SupportedChain = TupleToUnion<typeof SupportedChains>

export const isSupportedChain = (chain: unknown): chain is SupportedChain =>
    SupportedChains.includes(chain as any)

// Helper to check if a chain ID is valid for cross-chain operations
export const isValidChainId = (chainId: number): boolean => {
    return Object.values(NetworkEnum).includes(chainId) || 
           chainId === CardanoChainId.MAINNET || 
           chainId === CardanoChainId.TESTNET ||
           chainId === CardanoChainId.SEPOLIA_TESTNET
}
