# PackedAddresses
[Git Source](https://github.com/1inch/cross-chain-swap/blob/ebb85c41907258c27b301dda207e13dd189a6048/contracts/libraries/PackedAddressesLib.sol)


```solidity
struct PackedAddresses {
    uint256 addressesPart1;
    uint256 addressesPart2;
}
```

